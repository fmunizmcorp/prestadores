<?php header("Content-Type: text/plain"); echo "TEST FILE ACCESSIBLE\n"; echo "PHP Version: " . PHP_VERSION . "\n"; echo "Current Dir: " . getcwd() . "\n";
