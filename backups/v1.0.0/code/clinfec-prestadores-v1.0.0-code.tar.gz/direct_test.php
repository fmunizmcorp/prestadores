<?php
// Bypass router - direct PHP test
header('Content-Type: text/plain');
echo "DIRECT PHP EXECUTION WORKING\n";
echo "Timestamp: " . date('Y-m-d H:i:s') . "\n";
