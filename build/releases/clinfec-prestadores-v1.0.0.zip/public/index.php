<?php
/**
 * Sistema de Gestão de Prestadores - Clinfec
 * Arquivo de entrada principal com auto-instalação
 */

// Define o timezone
date_default_timezone_set('America/Sao_Paulo');

// Inicia a sessão
session_start();

// Autoload manual (sem composer)
spl_autoload_register(function ($class) {
    $prefix = 'App\\';
    $base_dir = __DIR__ . '/../src/';
    
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }
    
    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';
    
    if (file_exists($file)) {
        require $file;
    }
});

// Carrega helpers
require __DIR__ . '/../src/helpers.php';

// Configuração de erros
$config = require __DIR__ . '/../config/app.php';
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/php_errors_' . date('Y-m-d') . '.log');

// ========================================
// SISTEMA DE MIGRATIONS AUTOMÁTICAS
// ========================================
use App\DatabaseMigration;

try {
    $migration = new DatabaseMigration();
    
    // Verifica se precisa de instalação inicial
    if ($migration->needsInitialSetup()) {
        $result = $migration->runInitialSetup();
        error_log("Instalação inicial concluída: " . json_encode($result));
    }
    
    // Verifica e aplica migrations se necessário
    $migrationResult = $migration->checkAndMigrate();
    
    if (!$migrationResult['success']) {
        error_log("Erro nas migrations: " . $migrationResult['error']);
    }
    
} catch (Exception $e) {
    error_log("Erro crítico no sistema de migrations: " . $e->getMessage());
    // Sistema continua funcionando mesmo se migrations falharem
}

// Headers de segurança
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');

// Roteamento simples
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = str_replace('/prestadores', '', $uri); // Remove base path
$uri = trim($uri, '/');

// Importa controllers
use App\Controllers\AuthController;

// Define rotas
$routes = [
    '' => function() {
        redirect(base_url('login'));
    },
    'login' => function() {
        $controller = new AuthController();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $controller->login();
        } else {
            $controller->showLogin();
        }
    },
    'logout' => function() {
        $controller = new AuthController();
        $controller->logout();
    },
    'register' => function() {
        $controller = new AuthController();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $controller->register();
        } else {
            $controller->showRegister();
        }
    },
    'forgot-password' => function() {
        $controller = new AuthController();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $controller->forgotPassword();
        } else {
            $controller->showForgotPassword();
        }
    },
    'reset-password' => function() {
        $controller = new AuthController();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $controller->resetPassword();
        } else {
            $controller->showResetPassword();
        }
    },
    'dashboard' => function() {
        if (!is_authenticated()) {
            flash('error', 'Você precisa estar autenticado para acessar esta página');
            redirect(base_url('login'));
        }
        require __DIR__ . '/../src/views/dashboard/index.php';
    }
];

// Executa rota
if (isset($routes[$uri])) {
    try {
        $routes[$uri]();
    } catch (Exception $e) {
        error_log("Erro na rota /$uri: " . $e->getMessage());
        http_response_code(500);
        echo "Erro interno do servidor. Por favor, tente novamente mais tarde.";
    }
} else {
    http_response_code(404);
    echo "Página não encontrada";
}
