<?php
/**
 * Configuração de Banco de Dados
 * Sistema de Gestão de Prestadores - Clinfec
 */

return [
    'host' => 'localhost',
    'database' => 'u673902663_prestadores',
    'username' => 'u673902663_admin',
    'password' => ';>?I4dtn~2Ga',
    'charset' => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',
    'prefix' => '',
    'options' => [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]
];
