<?php 
$pageTitle = 'Dashboard';
$user = current_user();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - Sistema Clinfec</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/dashboard.css') ?>">
</head>
<body class="dashboard-layout">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <img src="<?= asset('images/logo.png') ?>" alt="Clinfec" class="sidebar-logo" onerror="this.style.display='none'">
            <h2>Clinfec</h2>
        </div>
        
        <nav class="sidebar-nav">
            <a href="<?= base_url('dashboard') ?>" class="nav-item active">
                <i class="fas fa-home"></i>
                <span>Dashboard</span>
            </a>
            
            <?php if (has_permission(60)): ?>
            <a href="<?= base_url('empresas') ?>" class="nav-item">
                <i class="fas fa-building"></i>
                <span>Empresas</span>
            </a>
            <?php endif; ?>
            
            <?php if (has_permission(60)): ?>
            <a href="<?= base_url('projetos') ?>" class="nav-item">
                <i class="fas fa-project-diagram"></i>
                <span>Projetos</span>
            </a>
            <?php endif; ?>
            
            <?php if (has_permission(60)): ?>
            <a href="<?= base_url('atividades') ?>" class="nav-item">
                <i class="fas fa-tasks"></i>
                <span>Atividades</span>
            </a>
            <?php endif; ?>
            
            <?php if (has_permission(80)): ?>
            <a href="<?= base_url('usuarios') ?>" class="nav-item">
                <i class="fas fa-users"></i>
                <span>Usuários</span>
            </a>
            <?php endif; ?>
            
            <?php if (has_permission(100)): ?>
            <a href="<?= base_url('configuracoes') ?>" class="nav-item">
                <i class="fas fa-cog"></i>
                <span>Configurações</span>
            </a>
            <?php endif; ?>
        </nav>
        
        <div class="sidebar-footer">
            <div class="user-info">
                <div class="user-avatar">
                    <?= strtoupper(substr($user['nome'], 0, 2)) ?>
                </div>
                <div class="user-details">
                    <strong><?= htmlspecialchars($user['nome']) ?></strong>
                    <small><?= ucfirst($user['role']) ?></small>
                </div>
            </div>
            <a href="<?= base_url('logout') ?>" class="btn-logout">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </aside>
    
    <!-- Main Content -->
    <main class="main-content">
        <header class="page-header">
            <div>
                <h1>Bem-vindo, <?= htmlspecialchars(explode(' ', $user['nome'])[0]) ?>! 👋</h1>
                <p>Aqui está um resumo das suas atividades</p>
            </div>
        </header>
        
        <?php if ($success = flash('success')): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <?= $success ?>
            </div>
        <?php endif; ?>
        
        <div class="dashboard-grid">
            <!-- Cards de Estatísticas -->
            <div class="stat-card stat-card-primary">
                <div class="stat-icon">
                    <i class="fas fa-building"></i>
                </div>
                <div class="stat-content">
                    <h3>Empresas</h3>
                    <p class="stat-number">0</p>
                    <span class="stat-label">cadastradas</span>
                </div>
            </div>
            
            <div class="stat-card stat-card-success">
                <div class="stat-icon">
                    <i class="fas fa-project-diagram"></i>
                </div>
                <div class="stat-content">
                    <h3>Projetos</h3>
                    <p class="stat-number">0</p>
                    <span class="stat-label">ativos</span>
                </div>
            </div>
            
            <div class="stat-card stat-card-warning">
                <div class="stat-icon">
                    <i class="fas fa-tasks"></i>
                </div>
                <div class="stat-content">
                    <h3>Atividades</h3>
                    <p class="stat-number">0</p>
                    <span class="stat-label">pendentes</span>
                </div>
            </div>
            
            <div class="stat-card stat-card-danger">
                <div class="stat-icon">
                    <i class="fas fa-dollar-sign"></i>
                </div>
                <div class="stat-content">
                    <h3>Pagamentos</h3>
                    <p class="stat-number">R$ 0,00</p>
                    <span class="stat-label">a pagar</span>
                </div>
            </div>
        </div>
        
        <div class="content-grid">
            <!-- Atividades Recentes -->
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-clock"></i> Atividades Recentes</h2>
                    <a href="#" class="btn btn-sm">Ver todas</a>
                </div>
                <div class="card-body">
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <p>Nenhuma atividade registrada ainda</p>
                    </div>
                </div>
            </div>
            
            <!-- Próximos Vencimentos -->
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-calendar-alt"></i> Próximos Vencimentos</h2>
                    <a href="#" class="btn btn-sm">Ver todos</a>
                </div>
                <div class="card-body">
                    <div class="empty-state">
                        <i class="fas fa-calendar-check"></i>
                        <p>Nenhum vencimento próximo</p>
                    </div>
                </div>
            </div>
        </div>
    </main>
    
    <script src="<?= asset('js/main.js') ?>"></script>
</body>
</html>
