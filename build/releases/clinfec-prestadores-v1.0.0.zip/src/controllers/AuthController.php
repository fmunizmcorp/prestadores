<?php
/**
 * Controller de Autenticação
 */

namespace App\Controllers;

use App\Models\Usuario;

class AuthController {
    private $usuarioModel;
    
    public function __construct() {
        $this->usuarioModel = new Usuario();
    }
    
    /**
     * Exibe página de login
     */
    public function showLogin() {
        if (is_authenticated()) {
            redirect(base_url('dashboard'));
        }
        
        require __DIR__ . '/../views/auth/login.php';
    }
    
    /**
     * Processa login
     */
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(base_url('login'));
        }
        
        // Valida CSRF
        if (!csrf_validate($_POST['csrf_token'] ?? '')) {
            flash('error', 'Token de segurança inválido');
            redirect(base_url('login'));
        }
        
        $email = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        
        // Validações básicas
        if (empty($email) || empty($password)) {
            flash('error', 'Email e senha são obrigatórios');
            redirect(base_url('login'));
        }
        
        // Busca usuário
        $user = $this->usuarioModel->findByEmail($email);
        
        if (!$user) {
            flash('error', 'Credenciais inválidas');
            redirect(base_url('login'));
        }
        
        // Verifica se está bloqueado
        if ($this->usuarioModel->isLocked($user)) {
            $bloqueadoAte = format_datetime($user['bloqueado_ate'], 'd/m/Y H:i');
            flash('error', "Conta bloqueada devido a múltiplas tentativas. Tente novamente após $bloqueadoAte");
            redirect(base_url('login'));
        }
        
        // Verifica senha
        if (!$this->usuarioModel->verifyPassword($user, $password)) {
            $this->usuarioModel->registerLoginAttempt($user['id'], false);
            flash('error', 'Credenciais inválidas');
            log_activity('LOGIN_FAILED', ['email' => $email]);
            redirect(base_url('login'));
        }
        
        // Verifica se está ativo
        if (!$user['ativo']) {
            flash('error', 'Sua conta está desativada. Entre em contato com o administrador.');
            redirect(base_url('login'));
        }
        
        // Login bem-sucedido
        $this->usuarioModel->registerLoginAttempt($user['id'], true);
        
        // Configura sessão
        $config = require __DIR__ . '/../../config/app.php';
        $roleLevel = $config['roles'][$user['role']]['level'] ?? 0;
        
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_nome'] = $user['nome'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['user_role_level'] = $roleLevel;
        
        // Regenera ID da sessão para segurança
        session_regenerate_id(true);
        
        log_activity('LOGIN_SUCCESS', ['user_id' => $user['id']]);
        
        flash('success', 'Bem-vindo, ' . $user['nome'] . '!');
        redirect(base_url('dashboard'));
    }
    
    /**
     * Logout
     */
    public function logout() {
        $userId = $_SESSION['user_id'] ?? null;
        
        if ($userId) {
            log_activity('LOGOUT', ['user_id' => $userId]);
        }
        
        $_SESSION = [];
        
        if (isset($_COOKIE[session_name()])) {
            setcookie(session_name(), '', time() - 3600, '/');
        }
        
        session_destroy();
        
        flash('success', 'Você saiu do sistema com sucesso');
        redirect(base_url('login'));
    }
    
    /**
     * Exibe página de registro
     */
    public function showRegister() {
        if (is_authenticated()) {
            redirect(base_url('dashboard'));
        }
        
        require __DIR__ . '/../views/auth/register.php';
    }
    
    /**
     * Processa registro
     */
    public function register() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(base_url('register'));
        }
        
        // Valida CSRF
        if (!csrf_validate($_POST['csrf_token'] ?? '')) {
            flash('error', 'Token de segurança inválido');
            redirect(base_url('register'));
        }
        
        // Valida reCAPTCHA
        if (!$this->validateRecaptcha($_POST['g-recaptcha-response'] ?? '')) {
            flash('error', 'Por favor, complete o captcha');
            redirect(base_url('register'));
        }
        
        $nome = sanitize($_POST['nome'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        
        // Validações
        $errors = [];
        
        if (empty($nome)) {
            $errors[] = 'Nome é obrigatório';
        }
        
        if (empty($email) || !validate_email($email)) {
            $errors[] = 'Email inválido';
        }
        
        if (empty($password)) {
            $errors[] = 'Senha é obrigatória';
        }
        
        // Valida complexidade da senha
        $config = require __DIR__ . '/../../config/app.php';
        $security = $config['security'];
        
        if (strlen($password) < $security['password_min_length']) {
            $errors[] = "Senha deve ter no mínimo {$security['password_min_length']} caracteres";
        }
        
        if ($security['password_require_uppercase'] && !preg_match('/[A-Z]/', $password)) {
            $errors[] = 'Senha deve conter pelo menos uma letra maiúscula';
        }
        
        if ($security['password_require_numbers'] && !preg_match('/[0-9]/', $password)) {
            $errors[] = 'Senha deve conter pelo menos um número';
        }
        
        if ($security['password_require_special'] && !preg_match('/[^A-Za-z0-9]/', $password)) {
            $errors[] = 'Senha deve conter pelo menos um caractere especial';
        }
        
        if ($password !== $confirmPassword) {
            $errors[] = 'As senhas não coincidem';
        }
        
        // Verifica se email já existe
        if ($this->usuarioModel->findByEmail($email)) {
            $errors[] = 'Este email já está cadastrado';
        }
        
        if (!empty($errors)) {
            flash('error', implode('<br>', $errors));
            redirect(base_url('register'));
        }
        
        // Cria usuário
        $result = $this->usuarioModel->create([
            'nome' => $nome,
            'email' => $email,
            'senha' => $password,
            'role' => 'usuario',
            'email_verificado' => false
        ]);
        
        if ($result) {
            log_activity('USER_REGISTERED', ['email' => $email]);
            
            // TODO: Enviar email de verificação
            // $this->sendVerificationEmail($email, $result['token_verificacao']);
            
            flash('success', 'Cadastro realizado com sucesso! Você já pode fazer login.');
            redirect(base_url('login'));
        } else {
            flash('error', 'Erro ao criar conta. Tente novamente.');
            redirect(base_url('register'));
        }
    }
    
    /**
     * Exibe página de esqueci a senha
     */
    public function showForgotPassword() {
        require __DIR__ . '/../views/auth/forgot_password.php';
    }
    
    /**
     * Processa recuperação de senha
     */
    public function forgotPassword() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(base_url('forgot-password'));
        }
        
        // Valida CSRF
        if (!csrf_validate($_POST['csrf_token'] ?? '')) {
            flash('error', 'Token de segurança inválido');
            redirect(base_url('forgot-password'));
        }
        
        // Valida reCAPTCHA
        if (!$this->validateRecaptcha($_POST['g-recaptcha-response'] ?? '')) {
            flash('error', 'Por favor, complete o captcha');
            redirect(base_url('forgot-password'));
        }
        
        $email = sanitize($_POST['email'] ?? '');
        
        $user = $this->usuarioModel->findByEmail($email);
        
        // Por segurança, sempre retorna sucesso
        flash('success', 'Se o email existir em nossa base, você receberá instruções para recuperação de senha.');
        
        if ($user) {
            $token = $this->usuarioModel->generatePasswordResetToken($user['id']);
            
            // TODO: Enviar email com link de recuperação
            // $this->sendPasswordResetEmail($email, $token);
            
            log_activity('PASSWORD_RESET_REQUESTED', ['user_id' => $user['id']]);
        }
        
        redirect(base_url('login'));
    }
    
    /**
     * Exibe página de resetar senha
     */
    public function showResetPassword() {
        $token = $_GET['token'] ?? '';
        
        if (empty($token)) {
            flash('error', 'Token inválido');
            redirect(base_url('login'));
        }
        
        $user = $this->usuarioModel->validateResetToken($token);
        
        if (!$user) {
            flash('error', 'Token inválido ou expirado');
            redirect(base_url('login'));
        }
        
        require __DIR__ . '/../views/auth/reset_password.php';
    }
    
    /**
     * Processa reset de senha
     */
    public function resetPassword() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect(base_url('login'));
        }
        
        $token = $_POST['token'] ?? '';
        $password = $_POST['password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        
        // Valida token
        $user = $this->usuarioModel->validateResetToken($token);
        
        if (!$user) {
            flash('error', 'Token inválido ou expirado');
            redirect(base_url('login'));
        }
        
        // Valida senha
        if ($password !== $confirmPassword) {
            flash('error', 'As senhas não coincidem');
            redirect(base_url('reset-password?token=' . $token));
        }
        
        // Reseta senha
        if ($this->usuarioModel->resetPassword($user['id'], $password)) {
            log_activity('PASSWORD_RESET_SUCCESS', ['user_id' => $user['id']]);
            flash('success', 'Senha alterada com sucesso! Faça login com sua nova senha.');
            redirect(base_url('login'));
        } else {
            flash('error', 'Erro ao alterar senha. Tente novamente.');
            redirect(base_url('reset-password?token=' . $token));
        }
    }
    
    /**
     * Valida reCAPTCHA
     */
    private function validateRecaptcha($response) {
        $config = require __DIR__ . '/../../config/app.php';
        
        if (!$config['recaptcha']['enabled']) {
            return true;
        }
        
        if (empty($response)) {
            return false;
        }
        
        $secretKey = $config['recaptcha']['secret_key'];
        $verifyUrl = 'https://www.google.com/recaptcha/api/siteverify';
        
        $data = [
            'secret' => $secretKey,
            'response' => $response,
            'remoteip' => $_SERVER['REMOTE_ADDR']
        ];
        
        $options = [
            'http' => [
                'method' => 'POST',
                'header' => 'Content-Type: application/x-www-form-urlencoded',
                'content' => http_build_query($data)
            ]
        ];
        
        $context = stream_context_create($options);
        $result = file_get_contents($verifyUrl, false, $context);
        $json = json_decode($result, true);
        
        return $json['success'] ?? false;
    }
}
