<?php
echo "<h1>✅ TESTE SPRINT 31 FUNCIONOU!</h1>";
echo "<p>Timestamp: " . date('Y-m-d H:i:s') . "</p>";
echo "<p>Este arquivo foi carregado corretamente!</p>";
