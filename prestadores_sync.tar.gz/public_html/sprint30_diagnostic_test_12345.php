<?php
echo "<!DOCTYPE html><html><body>";
echo "<h1>TESTE SPRINT 30 - ARQUIVO EXECUTOU CORRETAMENTE</h1>";
echo "<p>Se você está vendo isso, o arquivo foi carregado diretamente!</p>";
echo "<p>Timestamp: " . date('Y-m-d H:i:s') . "</p>";
echo "</body></html>";
