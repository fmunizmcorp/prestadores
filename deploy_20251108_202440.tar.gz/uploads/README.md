# Pasta de Uploads

Esta pasta armazena todos os arquivos enviados pelos usuários:
- Documentos de empresas tomadoras
- Documentos de empresas prestadoras
- Documentos de contratos
- Etc.

**IMPORTANTE:** Configure permissão 777 nesta pasta no Hostinger!
